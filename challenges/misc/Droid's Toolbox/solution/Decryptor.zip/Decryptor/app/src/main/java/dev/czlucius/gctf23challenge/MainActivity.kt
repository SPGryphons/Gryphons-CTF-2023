package dev.czlucius.gctf23challenge

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Base64
import android.widget.Button
import android.widget.EditText
import java.nio.charset.Charset
import java.security.KeyStore
import javax.crypto.Cipher

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val enc = findViewById<EditText>(R.id.enc)
        val decBtn = findViewById<Button>(R.id.decbtn)
        decBtn.setOnClickListener {
            val keyStore = KeyStore.getInstance("AndroidKeyStore")
            keyStore.load(null)
            var entry = keyStore.getEntry("CTF_TOOLBOX_3716", null)
            val privKey = (entry as KeyStore.PrivateKeyEntry).privateKey
            val cipher = Cipher.getInstance("RSA/ECB/OAEPwithSHA-1andMGF1Padding")
            cipher.init(Cipher.DECRYPT_MODE, privKey)
            val rawEncrypt = Base64.decode(enc.text.toString(), Base64.DEFAULT)
            enc.setText(cipher.doFinal(rawEncrypt).toString(Charset.defaultCharset()))

        }
    }

}