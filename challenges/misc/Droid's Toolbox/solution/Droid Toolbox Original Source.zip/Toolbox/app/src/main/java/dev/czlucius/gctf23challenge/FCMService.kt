package dev.czlucius.gctf23challenge

import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import android.widget.Toast
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

private const val TAG = "FCMService"
class FCMService : FirebaseMessagingService() {
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        if (remoteMessage.data.isNotEmpty()) {
            Log.d(TAG, "Message data payload: ${remoteMessage.data}")

            val sharedPreferences = applicationContext.getSharedPreferences(
                "DATA_STORAGE", MODE_PRIVATE
            )
            //data: {
            //            authToken
            //        }
            val token  = remoteMessage.data["authToken"] ?: return // Is not for this purpose.
            val encryptedToken = CipherTools.encrypt(token.encodeToByteArray())
            val encryptedTokenBase64 = Base64.encodeToString(encryptedToken, Base64.DEFAULT)
            sharedPreferences.edit()
                .putString("TOKEN", encryptedTokenBase64)
                .apply()

            Handler(Looper.getMainLooper()).post(Runnable {
                Toast.makeText(applicationContext, "Token Received!", Toast.LENGTH_LONG).show()
            })
        }

        // Check if message contains a notification payload.
        remoteMessage.notification?.let {
            Log.d(TAG, "Message Notification Body: ${it.body}")
        }


    }
}