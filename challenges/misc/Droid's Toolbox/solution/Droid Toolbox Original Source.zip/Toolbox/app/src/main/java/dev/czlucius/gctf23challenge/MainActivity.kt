package dev.czlucius.gctf23challenge

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.AttributeSet
import android.view.View
import android.widget.Button
import android.widget.Toast
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sign

class MainActivity : AppCompatActivity() {
    val coroutineScope = CoroutineScope(Dispatchers.IO)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val usernameTextInput = findViewById<TextInputLayout>(R.id.username_textinput)
        val passwordTextInput = findViewById<TextInputLayout>(R.id.password_textinput)
        val signin_btn = findViewById<Button>(R.id.signin_btn)

        signin_btn.setOnClickListener {
            val username  = usernameTextInput.editText!!.text.toString()
            val password = passwordTextInput.editText!!.text.toString()
            if (username == "@dmin" && password == "GCTF23{aNDR01D's_No-Op_KEY}") {
                Toast.makeText(this, R.string.login_correct, Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Login incorrect.", Toast.LENGTH_LONG).show()
            }
        }



    }



//    fun checkPassword(password: String, seed: Int = 63, length: Int): Boolean {
//        if (password.length != length) {
//            return false
//        }
//        var current = seed
//        var correct = true
//        for (char in password) {
//            val calculatedCode = char.code % 94 + 31
////            val calcChar = calculatedCode.toChar()
//            if (calculatedCode != current) {
//                correct = false
//                break
//            }
//            if (curre)
//        }
//    }


}