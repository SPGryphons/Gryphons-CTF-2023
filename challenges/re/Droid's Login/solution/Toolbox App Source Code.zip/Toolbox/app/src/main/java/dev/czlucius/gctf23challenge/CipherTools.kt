package dev.czlucius.gctf23challenge

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.FileWriter
import java.io.IOException
import java.nio.charset.Charset
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.KeyStore.Entry
import java.security.PrivateKey
import java.security.PublicKey
import javax.crypto.Cipher


object CipherTools {
    private const val alias = "CTF_TOOLBOX_3716"
    private val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA,"AndroidKeyStore")
    private val keyStore = KeyStore.getInstance("AndroidKeyStore")
    init {
        kpg.initialize(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_DECRYPT
                        or KeyProperties.PURPOSE_ENCRYPT
            )
                .setDigests(KeyProperties.DIGEST_SHA1)
                .setKeySize(2048)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_OAEP)
                .build()
        )

        keyStore.load(null)
        getEntry() // Ensure key pair's existence

    }


    private fun generateKeyPair(): KeyPair {
        return kpg.genKeyPair()
    }


    private fun getEntry(): Entry {
        var entry = keyStore.getEntry(alias, null)
        if (entry == null) {
            generateKeyPair()
            entry = keyStore.getEntry(alias, null)
        }
        return entry
    }

    fun getPublicKey(): PublicKey {
        return keyStore.getCertificate(alias).publicKey
    }

    private fun getPrivateKey(): PrivateKey {
        return (getEntry() as KeyStore.PrivateKeyEntry).privateKey
    }

    fun getPem(publicKey: PublicKey): String {
        // Convert public key to byte array
        val keyBytes = publicKey.encoded

        // Encode byte array to Base64 string
        var keyString = Base64.encodeToString(keyBytes, Base64.DEFAULT)

        // Add PEM header and footer
        keyString = "-----BEGIN PUBLIC KEY-----\n$keyString-----END PUBLIC KEY-----"

        return keyString
    }



    fun getServerToken(context: Context): String? {
        val sharedPreferences = context.getSharedPreferences("DATA_STORAGE", Context.MODE_PRIVATE)
        val encryptedToken = sharedPreferences.getString("TOKEN", null) ?: return null
        val encryptedBytes = Base64.decode(encryptedToken, Base64.DEFAULT)
        val decryptedBytes = decrypt(encryptedBytes)
        return decryptedBytes.toString(Charset.defaultCharset())
    }


    fun decrypt(data: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("RSA/ECB/OAEPwithSHA-1andMGF1Padding")
        val privateKey = getPrivateKey()
        cipher.init(Cipher.DECRYPT_MODE, privateKey)

        return cipher.doFinal(data)
    }


    fun encrypt(data: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("RSA/ECB/OAEPwithSHA-1andMGF1Padding")
        val publicKey = getPublicKey()
        cipher.init(Cipher.ENCRYPT_MODE, publicKey)

        return cipher.doFinal(data)
    }


}