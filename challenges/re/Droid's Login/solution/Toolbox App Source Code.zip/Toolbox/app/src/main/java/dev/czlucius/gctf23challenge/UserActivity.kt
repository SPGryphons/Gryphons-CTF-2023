package dev.czlucius.gctf23challenge

import android.R
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.ui.AppBarConfiguration
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.ktx.Firebase
import com.google.firebase.messaging.ktx.messaging
import dev.czlucius.gctf23challenge.databinding.ActivityUserBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import org.json.JSONTokener
import java.io.IOException


class UserActivity : AppCompatActivity() {


    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityUserBinding

    private val HOST_URL: String?
        get() {
            if (!this::binding.isInitialized) {
                return null
            } else {
                return binding.content.urlChooser.selectedItem as String
            }
        }
    override fun onCreate(savedInstanceState: Bundle?) {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        super.onCreate(savedInstanceState)

        binding = ActivityUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)


        val content = binding.content


        content.refreshServerTokenBtn.setOnClickListener {
            requestToken()
        }
        content.getFlagBtn.setOnClickListener {
            lifecycleScope.launch(Dispatchers.IO) {
                requestFlag()
            }
        }

        populateChooser()

    }

    fun populateChooser() {
        lifecycleScope.launch(Dispatchers.IO) {
            val okHttpClient = OkHttpClient()
            val request = Request.Builder()
                .url("https://gh.czlucius.dev/gctf-droid-get-server/endpoints.json")
                .get()
                .build()

            var response: Response? = null
            try {
                response = okHttpClient.newCall(request).execute() // BLOCKING CALL
                withContext(Dispatchers.Main) {
                    if (response.isSuccessful) {
                        val data = response?.body?.string()
                        val jsonResponse: JSONArray? = JSONTokener(data).nextValue() as? JSONArray
                        if (jsonResponse == null) {
                            Toast.makeText(this@UserActivity, "Server lookup failed: JSON invalid", Toast.LENGTH_LONG).show()
                            return@withContext
                        }
                        val servers = mutableListOf<String>()
                        var count = 0;
                        while(true) {
                            try {
                                servers.add(jsonResponse.get(count) as String)
                            } catch (e: JSONException) {
                                break
                            }
                            count++
                        }

                        Log.i("UserActivity", "populateChooser: JSON object $jsonResponse")

                        val ad = ArrayAdapter<String>(
                            this@UserActivity,
                            R.layout.simple_spinner_item,
                            servers
                        )
                        ad.setDropDownViewResource(
                            R.layout.simple_spinner_dropdown_item
                        )
                        binding.content.urlChooser.adapter = ad
                    } else {
                        Toast.makeText(this@UserActivity, "Server lookup failed", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    suspend fun requestFlag() {
        val okHttpClient = OkHttpClient()
        val jsonBody = JSONObject()
        val mediaType = "application/json; charset=utf-8".toMediaType()
        val serverToken = CipherTools.getServerToken(this)
        if (serverToken == null) {
            withContext(Dispatchers.Main) {
                Toast.makeText(
                    this@UserActivity,
                    "Server Interaction Token is not registered!",
                    Toast.LENGTH_LONG
                ).show()
            }

            return
        }


        val publicKey = CipherTools.getPublicKey()
        val key = CipherTools.getPem(publicKey)
        jsonBody.put("publicKey", key)

        val body = jsonBody.toString().toRequestBody(mediaType)
        val url = "$HOST_URL/flag"
        Log.i("UserActivity", "requestFlag: $url")
        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $serverToken")
            .post(body)
            .build()
        var response: Response? = null
        try {
            response = okHttpClient.newCall(request).execute() // BLOCKING CALL
            withContext(Dispatchers.Main) {
                if (response.isSuccessful) {
                    val data = response?.body?.string()
                    val editText = EditText(this@UserActivity)
                    editText.setText(data)
                    MaterialAlertDialogBuilder(this@UserActivity)
                        .setView(editText)
                        .setTitle("Here's your encrypted flag... in Base64")
                        .show()
                } else {
                    Log.i("UserActivity", "Response unsuccessful")
                    Log.i("UserActivity", response?.body?.string() ?: "null")

                    Toast.makeText(this@UserActivity, "Request failed", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
            return
        }
    }




    fun requestToken() {
        val okHttpClient = OkHttpClient()
        val jsonBody = JSONObject()
        val mediaType = "application/json; charset=utf-8".toMediaType()

        lifecycleScope.launch(Dispatchers.IO) {
            val token = Firebase.messaging.token.await()
            jsonBody.put("token", token)
            val body = jsonBody.toString().toRequestBody(mediaType)
            val url = "$HOST_URL/sendAuthorizationToken"
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()
            var response: Response? = null
            try {
                response = okHttpClient.newCall(request).execute() // BLOCKING CALL
                withContext(Dispatchers.Main) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@UserActivity, "Request succeeded", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this@UserActivity, "Request failed", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: IOException) {
                e.printStackTrace()
                return@launch
            }


        }
    }

}