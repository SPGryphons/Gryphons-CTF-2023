from blueprints.api import api
from blueprints.otp import otp
from blueprints.web import web