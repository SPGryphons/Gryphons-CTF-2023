from blueprints.api import api
from blueprints.web import web